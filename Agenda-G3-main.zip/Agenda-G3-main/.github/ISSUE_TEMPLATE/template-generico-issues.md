---
name: Template genérico de Issues
about: Template para assuntos diversos como documentação e configuração de ferramentas
title: ''
labels: ''
assignees: ''

---

## Descrição

<!-- Descrever de forma sucinta os diversos aspectos da issue: motivação e objetivo  -->
<!-- Exemplo: Com o objetivo de <motivação>, essa issue busca <objetivo> -->

## Tarefas

<!-- Enumerar as tarefas necessárias para concluir a issue -->
<!-- - [ ] Tarefa 1. -->

## Critérios de Aceitação

<!-- Enumerar os critérios de aceitação dessa issue -->
<!-- - Exemplo 1. -->

<!-- ## Observações -->

<!-- Informações adicionais que ajudem no desenvolvimento da issue. -->
