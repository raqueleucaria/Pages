# Tema do projeto

![Super Agenda](https://user-images.githubusercontent.com/81540491/129607110-3a5a8972-01db-450e-9835-bc93c615b543.png)

Um super aplicativo de organização acadêmica que permite gerenciar seus horários, associar com as suas displinas, receber e calcular suas notas. Além disso, é possível separar as tarefas concluídas e pendentes, personalizar as matérias por cor, professor... E claro, a super agenda vai te lembrar quando tiver um evento importante chegando.

## Grupo 3 - Integrantes
- Fernando Vargas
- Raquel Eucaria
- Hoton Carmo
- João Lucas Pinto
- Eduardo Santos
- Pedro Henrique
- Raul Fragoso


