# Cronograma

| Data       | Autor                                        | Modificações                      | Versão |
| ---------- | -------------------------------------------- | --------------------------------- | ------ |
| 16/08/2021 | [Fernando Vargas](https://github.com/SFernandoS) | Criação do Documento | 1.0    |

<br><br>
![C1](https://user-images.githubusercontent.com/54643557/129577101-e8907673-dae3-4b55-992b-818e9da101b7.PNG)
<br><br>
![C2](https://user-images.githubusercontent.com/54643557/129577114-de65483d-9e6b-462e-896b-d57383311af2.PNG)
<br>
