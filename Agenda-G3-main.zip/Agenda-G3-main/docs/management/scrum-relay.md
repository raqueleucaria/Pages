# Revezamento do Scrum Master

| Data       | Autor                                        | Modificações                      | Versão |
| ---------- | -------------------------------------------- | --------------------------------- | ------ |
| 16/08/2021 | [Fernando Vargas](https://github.com/SFernandoS) | Criação do Documento | 1.0    |


## Introdução
De acordo com um dos plano metodológico, Scrum, adotado na disciplina, foi-se acordado para o melhor aproveitamento didático, os papéis Scrum Master, PO e Scrum Team serão
revezados. O revezamento acontecerá de Sprint em Sprint.

## Relação

| Sprint       | Scrum Master                              | PO                      | Scrum Team |
| ---------- | -------------------------------------------- | ------------------------------ | ------ |
| Sprint 0 | [Fernando Vargas](https://github.com/SFernandoS) | Hoton Carmo | Demais membros    |
| Sprint 1 | Raquel Eucaria | [Fernando Vargas](https://github.com/SFernandoS) | Demais membros    |
| Sprint 2 | Hoton Carmo | Raquel Eucaria | Demais membros    |
| Sprint 3 | Eduardo Santos | Pedro Henrique | Demais membros    |
| Sprint 4 | Joao Lucas | Eduardo Santos | Demais membros    |
| Sprint 5 | Pedro Henrique | Joao Lucas| Demais membros    |
| Sprint 6 | Raul | [Fernando Vargas](https://github.com/SFernandoS) | Demais membros    |
| Sprint 7 | Raquel Eucaria | Raul | Demais membros    |
| Sprint 8 | Hoton Carmo | Raquel Eucaria | Demais membros    |

